#include "cpu.h"
#include "iic.h"

void IIC_Init(void)
{
}

void IIC_Start(void)
{
}

void IIC_Stop(void)
{
}

UINT8 IIC_RecvACK(void)
{
	UINT8 dat;
	
	return dat;
}

void IIC_SendACK(void)
{
}

void IIC_SendNAK(void)
{
}

UINT8 IIC_RecvData(void)
{
	UINT8 dat;
	
	return dat;
}

void IIC_SendData(UINT8 dat)
{
}
